﻿// See https://aka.ms/new-console-template for more information

//PART 1-1
//for (int i = 1; i <= 100; i++)
//{
//    if (i % 3 == 0 && i % 5 == 0) Console.WriteLine($"{i} FIZZBUZZ");
//    else if (i % 3 == 0) Console.WriteLine($"{i} FIZZ");
//    else if (i % 5 == 0) Console.WriteLine($"{i} BUZZ");
//}

//Console.ReadKey();


//PART 1-2
Console.Write("Input: ");
var str = Console.ReadLine();

var chars = str.ToCharArray();
var newStr = string.Empty;

for (int i = chars.Length; i >0 ; i--)
{
    newStr += chars[i-1];
}

Console.WriteLine($"Output: {newStr}");

Console.ReadKey();
