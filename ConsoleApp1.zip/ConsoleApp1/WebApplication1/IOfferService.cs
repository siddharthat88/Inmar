﻿namespace WebApplication1
{
    public interface IOfferService
    {
        List<Product> GetAllProducts();
        List<Offer> GetTodaysOffers();
        void AddProduct(Product p);
    }
}
