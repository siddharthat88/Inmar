using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;
        private readonly IOfferService _offerService;

        public WeatherForecastController(ILogger<WeatherForecastController> logger, IOfferService offerService)
        {
            _logger = logger;
            _offerService = offerService;
        }

        [HttpGet(Name = "GetTodaysOffers")]
        public List<Offer> GetTodaysOffers()
        {
            return _offerService.GetTodaysOffers();
        }

        //TODO: order by and get 3 last
        [HttpGet(Name = "GetLeast3Products")]
        public List<Product> GetLeast3Products()
        {
            return _offerService.GetAllProducts().FindAll(x=> x.Price >100);
        }

        //TODO: order by and get 3 last
        [HttpPost(Name = "AddProduct")]
        public IActionResult GetAllProducts(Product p)
        {
            _offerService.AddProduct(p);
            return Ok();
        }
    }
}